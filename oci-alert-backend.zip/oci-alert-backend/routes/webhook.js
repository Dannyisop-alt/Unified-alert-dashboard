const express = require('express');
const cron = require('node-cron');
const router = express.Router();

// Memory storage for alerts (unlimited capacity)
const alertMemory = [];
const rawWebhookMemory = []; // Store raw webhook data for debugging
const MAX_ALERTS = 10000; // Set a high limit but not unlimited to prevent memory issues
const MAX_RAW_WEBHOOKS = 50; // Store last 50 raw webhook payloads

// 🕐 DAILY RESET SCHEDULER - Every day at 12:05 AM (same as application logs)
cron.schedule('5 0 * * *', () => {
  const beforeCount = alertMemory.length;
  const rawWebhookCount = rawWebhookMemory.length;
  alertMemory.length = 0; // Clear the memory array
  rawWebhookMemory.length = 0; // Clear raw webhook memory
  const resetTime = new Date().toISOString();
  console.log(`🧹 [CRON] OCI Alert Memory Reset: Cleared ${beforeCount} alerts and ${rawWebhookCount} raw webhooks at ${resetTime}`);
}, {
  timezone: "America/New_York" // Same timezone as application logs
});

// Webhook endpoint to receive OCI alerts and broadcast to frontend
router.post('/oci-alerts', async (req, res) => {
  try {
    console.log('🔔 [WEBHOOK] Received OCI alert webhook:', JSON.stringify(req.body, null, 2));
    
    const webhookData = req.body;
    
    // Store raw webhook data for debugging
    const rawWebhookData = {
      id: `raw-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      timestamp: new Date().toISOString(),
      rawPayload: JSON.parse(JSON.stringify(req.body)), // Deep copy
      headers: req.headers
    };
    
    rawWebhookMemory.unshift(rawWebhookData); // Add to beginning
    if (rawWebhookMemory.length > MAX_RAW_WEBHOOKS) {
      rawWebhookMemory.splice(MAX_RAW_WEBHOOKS);
    }
    
    // Validate webhook data structure - check for either alarmSummary or name field
    if (!webhookData || (!webhookData.alarmSummary && !webhookData.name)) {
      console.error('❌ [WEBHOOK] Invalid webhook data structure - missing alarmSummary or name');
      return res.status(400).json({ error: 'Invalid webhook data structure - missing alarmSummary or name' });
    }

    // Extract alert information from webhook payload
    const alertData = {
      id: webhookData.alarmOCID || `webhook-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      severity: webhookData.severity?.toLowerCase() || 'warning',
      message: webhookData.name || webhookData.alarmSummary || 'Unknown Alert',
      vm: extractResourceDisplayName(webhookData.dimensions),
      tenant: extractTenantFromCompartment(webhookData.dimensions),
      region: extractRegionFromDimensions(webhookData.dimensions),
      compartment: extractCompartmentFromDimensions(webhookData.dimensions),
      alertType: webhookData.type || 'REPEAT',
      metricName: extractMetricName(webhookData.query),
      threshold: extractThreshold(webhookData.query),
      currentValue: extractCurrentValue(webhookData.metricValues),
      unit: extractUnit(webhookData.query),
      resourceDisplayName: extractResourceDisplayName(webhookData.dimensions),
      metricValues: webhookData.metricValues && Array.isArray(webhookData.metricValues) && webhookData.metricValues.length > 0 
        ? webhookData.metricValues[0] 
        : {},
      query: webhookData.query,
      timestamp: webhookData.time || new Date().toISOString(),
      webhookReceivedAt: new Date().toISOString()
      // Note: Sensitive data (alarmOCID, dedupeKey, imageId, resourceId) is excluded
    };

    // Store alert in memory array
    alertMemory.unshift(alertData); // Add to beginning of array (newest first)
    
    // Keep only the latest MAX_ALERTS to prevent memory issues
    if (alertMemory.length > MAX_ALERTS) {
      alertMemory.splice(MAX_ALERTS);
    }
    
    console.log('✅ [WEBHOOK] Alert stored in memory:', {
      id: alertData.id,
      message: alertData.message,
      severity: alertData.severity,
      vm: alertData.vm,
      tenant: alertData.tenant,
      totalAlerts: alertMemory.length,
      memoryUsage: `${alertMemory.length}/${MAX_ALERTS} (${((alertMemory.length / MAX_ALERTS) * 100).toFixed(1)}%)`
    });

    res.status(200).json({ 
      message: 'Alert received and stored successfully',
      alertId: alertData.id,
      totalAlerts: alertMemory.length
    });

  } catch (error) {
    console.error('❌ [WEBHOOK] Error processing webhook:', error);
    res.status(500).json({ error: 'Failed to process webhook' });
  }
});

// Get all alerts from memory
router.get('/alerts', (req, res) => {
  try {
    console.log(`📋 [MEMORY] Fetching ${alertMemory.length} alerts from memory`);
    
    // Apply filters from query parameters
    const { 
      severity, 
      vm, 
      tenant, 
      region, 
      alertType,
      limit
    } = req.query;
    
    let filteredAlerts = [...alertMemory]; // Create a copy
    
    if (severity && severity !== 'all') {
      filteredAlerts = filteredAlerts.filter(alert => 
        alert.severity.toLowerCase() === severity.toLowerCase()
      );
    }
    
    if (vm && vm !== 'all') {
      filteredAlerts = filteredAlerts.filter(alert => 
        alert.vm && alert.vm.toLowerCase().includes(vm.toLowerCase())
      );
    }
    
    if (tenant && tenant !== 'all') {
      filteredAlerts = filteredAlerts.filter(alert => 
        alert.tenant && alert.tenant.toLowerCase() === tenant.toLowerCase()
      );
    }
    
    if (region && region !== 'all') {
      filteredAlerts = filteredAlerts.filter(alert => 
        alert.region && alert.region.toLowerCase() === region.toLowerCase()
      );
    }
    
    if (alertType && alertType !== 'all') {
      filteredAlerts = filteredAlerts.filter(alert => 
        alert.alertType && alert.alertType.toLowerCase() === alertType.toLowerCase()
      );
    }
    
    // Apply limit if specified
    if (limit && parseInt(limit) > 0) {
      filteredAlerts = filteredAlerts.slice(0, parseInt(limit));
    }
    
    console.log(`✅ [MEMORY] Returning ${filteredAlerts.length} filtered alerts`);
    res.json(filteredAlerts);
    
  } catch (error) {
    console.error('❌ [MEMORY] Error fetching alerts:', error);
    res.status(500).json({ error: 'Failed to fetch alerts' });
  }
});

// Get unique values for filters
router.get('/filters', (req, res) => {
  try {
    const vms = [...new Set(alertMemory.map(alert => alert.vm).filter(Boolean))];
    const tenants = [...new Set(alertMemory.map(alert => alert.tenant).filter(Boolean))];
    const regions = [...new Set(alertMemory.map(alert => alert.region).filter(Boolean))];
    const alertTypes = [...new Set(alertMemory.map(alert => alert.alertType).filter(Boolean))];
    const severities = [...new Set(alertMemory.map(alert => alert.severity).filter(Boolean))];

    res.json({
      vms,
      tenants,
      regions,
      alertTypes,
      severities
    });
    
  } catch (error) {
    console.error('❌ [MEMORY] Error fetching filter options:', error);
    res.status(500).json({ error: 'Failed to fetch filter options' });
  }
});

// Health check endpoint
router.get('/health', (req, res) => {
  res.json({
    status: 'OK',
    totalAlerts: alertMemory.length,
    timestamp: new Date().toISOString(),
    mode: 'Memory storage'
  });
});

// DEBUG: Raw webhook data endpoint - shows actual raw webhook payloads
router.get('/debug/raw-webhooks', (req, res) => {
  try {
    const limit = parseInt(req.query.limit) || 10;
    const recentRawWebhooks = rawWebhookMemory.slice(0, limit);
    
    res.json({
      message: `Last ${recentRawWebhooks.length} raw webhook payloads`,
      totalRawWebhooks: rawWebhookMemory.length,
      totalProcessedAlerts: alertMemory.length,
      recentRawWebhooks: recentRawWebhooks,
      note: 'This shows the actual raw JSON data received from OCI webhooks'
    });
  } catch (error) {
    console.error('❌ [DEBUG] Error fetching raw webhook data:', error);
    res.status(500).json({ error: 'Failed to fetch raw webhook data' });
  }
});

// Clear all alerts (for testing)
router.delete('/alerts', (req, res) => {
  try {
    const clearedCount = alertMemory.length;
    alertMemory.length = 0; // Clear the array
    console.log(`🧹 [MANUAL] OCI Alert Memory Reset: Cleared ${clearedCount} alerts`);
    res.json({ 
      message: `Cleared ${clearedCount} alerts from memory`,
      clearedCount,
      resetTime: new Date().toISOString()
    });
  } catch (error) {
    console.error('❌ [MANUAL] Error clearing alerts:', error);
    res.status(500).json({ error: 'Failed to clear alerts' });
  }
});

// Get memory status
router.get('/status', (req, res) => {
  try {
    res.json({
      totalAlerts: alertMemory.length,
      maxAlerts: MAX_ALERTS,
      memoryUsage: `${alertMemory.length}/${MAX_ALERTS} (${((alertMemory.length / MAX_ALERTS) * 100).toFixed(1)}%)`,
      lastReset: 'Daily at 12:05 AM (America/New_York)',
      nextReset: 'Next reset at 12:05 AM tomorrow'
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to get memory status' });
  }
});

// Helper functions to extract data from webhook payload
function extractResourceDisplayName(dimensions) {
  if (!dimensions || !Array.isArray(dimensions) || dimensions.length === 0) {
    return 'N/A';
  }
  
  const dimension = dimensions[0];
  return dimension.resourceDisplayName || 'N/A';
}

function extractTenantFromCompartment(dimensions) {
  if (!dimensions || !Array.isArray(dimensions) || dimensions.length === 0) {
    return 'Unknown Tenant';
  }
  
  // For now, return a placeholder - in production, you might want to map compartment IDs to tenant names
  return 'GATRA'; // Default tenant name
}

function extractRegionFromDimensions(dimensions) {
  if (!dimensions || !Array.isArray(dimensions) || dimensions.length === 0) {
    return 'us-ashburn-1'; // Default region
  }
  
  const dimension = dimensions[0];
  return dimension.region || 'us-ashburn-1';
}

function extractCompartmentFromDimensions(dimensions) {
  if (!dimensions || !Array.isArray(dimensions) || dimensions.length === 0) {
    return 'N/A';
  }
  
  const dimension = dimensions[0];
  return dimension.compartmentId || 'N/A';
}

function extractMetricName(query) {
  if (!query) return 'Unknown';
  
  // Extract metric name from query like "CpuUtilization[5m].percentile(.90) > 80"
  const match = query.match(/^([A-Za-z]+)\[/);
  return match ? match[1] : 'Unknown';
}

function extractThreshold(query) {
  if (!query) return null;
  
  // Extract threshold from query like "CpuUtilization[5m].percentile(.90) > 80"
  const match = query.match(/>\s*(\d+(?:\.\d+)?)/);
  return match ? parseFloat(match[1]) : null;
}

function extractCurrentValue(metricValues) {
  if (!metricValues || !Array.isArray(metricValues) || metricValues.length === 0) {
    return null;
  }
  
  const metricValue = metricValues[0];
  if (metricValue && typeof metricValue === 'object') {
    const values = Object.values(metricValue);
    return values.length > 0 ? parseFloat(values[0]) : null;
  }
  
  return null;
}

function extractUnit(query) {
  if (!query) return '%';
  
  // Default to percentage for CPU utilization
  if (query.toLowerCase().includes('cpu')) {
    return '%';
  }
  
  return '%';
}

function extractImageId(dimensions) {
  if (!dimensions || !Array.isArray(dimensions) || dimensions.length === 0) {
    return null;
  }
  
  const dimension = dimensions[0];
  return dimension.imageId || null;
}

function extractResourceId(dimensions) {
  if (!dimensions || !Array.isArray(dimensions) || dimensions.length === 0) {
    return null;
  }
  
  const dimension = dimensions[0];
  return dimension.resourceId || null;
}

module.exports = router;
