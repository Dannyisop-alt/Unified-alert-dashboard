// AUTHENTICATION DISABLED FOR TESTING
export type UserAccess = 'Infrastructure Alerts' | 'Application Logs' | 'Application Heartbeat';
export type UserRole = 'admin' | 'user';

// const TOKEN_KEY = 'auth_token';
// const ACCESS_KEY = 'auth_access';
// const EMAIL_KEY = 'auth_email';
// const ROLE_KEY = 'auth_role';

export function saveAuth(token: string, access: string[], email?: string, role?: UserRole) {
  console.log('💾 [AUTH] Authentication disabled for testing');
  // console.log('💾 [AUTH] Saving authentication data...');
  // console.log(`🎫 [AUTH] Token: ${token.substring(0, 50)}...`);
  // console.log(`📋 [AUTH] Access: ${JSON.stringify(access)}`);
  // console.log(`📧 [AUTH] Email: ${email}`);
  // console.log(`👑 [AUTH] Role: ${role}`);
  
  // localStorage.setItem(TOKEN_KEY, token);
  // localStorage.setItem(ACCESS_KEY, JSON.stringify(access));
  // if (email) localStorage.setItem(EMAIL_KEY, email);
  // if (role) localStorage.setItem(ROLE_KEY, role);
  
  // console.log('✅ [AUTH] Authentication data saved to localStorage');
}

export function clearAuth() {
  console.log('🧹 [AUTH] Clear auth called (disabled for testing)');
  // localStorage.removeItem(TOKEN_KEY);
  // localStorage.removeItem(ACCESS_KEY);
  // localStorage.removeItem(EMAIL_KEY);
  // localStorage.removeItem(ROLE_KEY);
}

export function getToken(): string | null {
  // return localStorage.getItem(TOKEN_KEY);
  return 'mock-token-for-testing';
}

export function getAccess(): UserAccess[] {
  // const raw = localStorage.getItem(ACCESS_KEY);
  // try {
  //   const parsed = raw ? JSON.parse(raw) : [];
  //   return Array.isArray(parsed) ? parsed : [];
  // } catch {
  //   return [];
  // }
  return ['Infrastructure Alerts', 'Application Logs', 'Application Heartbeat'];
}

export function getRole(): UserRole {
  // return (localStorage.getItem(ROLE_KEY) as UserRole) || 'user';
  return 'admin';
}

export function getEmail(): string | null {
  // return localStorage.getItem(EMAIL_KEY);
  return 'test@example.com';
}

export function isAuthenticated(): boolean {
  // const token = getToken();
  // const hasToken = !!token;
  // console.log(`🔍 [AUTH] Checking authentication: ${hasToken ? 'AUTHENTICATED' : 'NOT AUTHENTICATED'}`);
  // if (hasToken) {
  //   console.log(`🎫 [AUTH] Token: ${token.substring(0, 50)}...`);
  // }
  // return hasToken;
  console.log('🔍 [AUTH] Authentication disabled - always authenticated for testing');
  return true;
}

export function isAdmin(): boolean {
  // const role = getRole();
  // const isAdminUser = role === 'admin';
  // console.log(`👑 [AUTH] Checking admin status: ${isAdminUser ? 'ADMIN' : 'USER'} (role: ${role})`);
  // return isAdminUser;
  console.log('👑 [AUTH] Admin check disabled - always admin for testing');
  return true;
}





