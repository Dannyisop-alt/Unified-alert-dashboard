import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
// import Login from "./pages/Login";
// import AdminDashboard from "./pages/AdminDashboard";
// import CreateUser from "./pages/CreateUser";
// import EditUser from "./pages/EditUsers";
// import { ProtectedRoute } from "./components/ProtectedRoute.tsx"; // Use the new dedicated component

const queryClient = new QueryClient();

const App = () => {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            {/* Direct access to dashboard without authentication */}
            <Route path="/" element={<Index />} />
            <Route path="/dashboard" element={<Index />} />
            
            {/* Commented out auth routes */}
            {/* <Route path="/login" element={<Login />} /> */}
            {/* <Route path="/admin" element={<AdminDashboard />} /> */}
            {/* <Route path="/admin/create-user" element={<CreateUser />} /> */}
            {/* <Route path="/admin/edit-user/:userId" element={<EditUser />} /> */}

            {/* CATCH-ALL "*" ROUTE */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </QueryClientProvider>
  );
};

export default App;
