import type { GraylogAlert, OCIAlert } from '@/types/alerts';

export const mockGraylogAlerts: GraylogAlert[] = [
  {
    channel: "#alerts",
    shortMessage: "Critical issue detected", 
    fullMessage: "Database connection failed on RTD-PROD-02",
    severity: "critical",
    color: "#FF0000",
    timestamp: "2025-08-13T06:32:00Z"
  },
  {
    channel: "#monitoring",
    shortMessage: "Performance warning",
    fullMessage: "High CPU usage detected on RTD-PROD-01 (85%)",
    severity: "medium",
    color: "#FFA500",
    timestamp: "2025-08-13T06:28:15Z"
  },
  {
    channel: "#info",
    shortMessage: "System notification",
    fullMessage: "Backup completed successfully for all production systems",
    severity: "info",
    color: "#008000",
    timestamp: "2025-08-13T06:15:30Z"
  },
  {
    channel: "#security",
    shortMessage: "Security alert",
    fullMessage: "Failed login attempts detected from suspicious IP",
    severity: "critical",
    color: "#FF0000",
    timestamp: "2025-08-13T06:10:45Z"
  },
  {
    channel: "#infrastructure",
    shortMessage: "Infrastructure alert",
    fullMessage: "Network connectivity issues detected in data center",
    severity: "critical",
    color: "#FF0000",
    timestamp: "2025-08-13T06:08:30Z"
  },
  {
    channel: "#maintenance",
    shortMessage: "Maintenance notification",
    fullMessage: "Scheduled maintenance window starting in 2 hours",
    severity: "medium",
    color: "#FFA500",
    timestamp: "2025-08-13T05:45:20Z"
  }
];

export const mockOCIAlerts: OCIAlert[] = [
  {
    severity: "info",
    message: "All services operational",
    vm: "RTD-PROD-01",
    tenant: "production",
    region: "us-east-1",
    timestamp: "2025-08-11T06:23:45Z"
  },
  {
    severity: "critical",
    message: "Web service down",
    vm: "RTD-PROD-02",
    tenant: "production", 
    region: "us-east-1",
    timestamp: "2025-08-11T06:21:12Z"
  },
  {
    severity: "medium",
    message: "IVR reporting warnings",
    vm: "RTD-DEV-01",
    tenant: "development",
    region: "us-west-2",
    timestamp: "2025-08-11T06:20:30Z"
  },
  {
    severity: "medium",
    message: "Database performance degraded",
    vm: "RTD-STAGE-01",
    tenant: "staging",
    region: "us-west-2",
    timestamp: "2025-08-11T06:19:15Z"
  }
];