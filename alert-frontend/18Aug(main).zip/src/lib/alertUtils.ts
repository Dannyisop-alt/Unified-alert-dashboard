import type { GraylogAlert, OCIAlert, AlertFilters, ProcessedAlert } from '@/types/alerts';

export const processAlerts = (
  graylogAlerts: GraylogAlert[],
  ociAlerts: OCIAlert[],
  filters: AlertFilters
): ProcessedAlert[] => {
  const processedAlerts: ProcessedAlert[] = [];

  // Process Graylog alerts
  graylogAlerts.forEach((alert) => {
    let severity: 'Critical' | 'Warning' | 'Info' = 'Info';
    
    // Map backend severity to frontend severity
    if (alert.severity === 'critical' || alert.severity === 'high') severity = 'Critical';
    else if (alert.severity === 'medium' || alert.severity === 'low') severity = 'Warning';
    else severity = 'Info';

    // Determine category based on channel
    let category: 'heartbeat' | 'logs' | 'infrastructure' = 'logs';
    if (alert.channel?.includes('heartbeat') || alert.channel?.includes('monitor')) {
      category = 'heartbeat';
    } else if (alert.channel?.includes('infrastructure') || alert.channel?.includes('system')) {
      category = 'infrastructure';
    }

    processedAlerts.push({
      id: alert._id || `graylog-${alert.timestamp}`,
      source: 'Application Logs',
      severity,
      title: alert.shortMessage || 'No title',
      description: alert.fullMessage || alert.shortMessage || 'No description',
      timestamp: alert.timestamp,
      category
    });
  });

  // Process OCI alerts
  ociAlerts.forEach((alert) => {
    let severity: 'Critical' | 'Warning' | 'Info' = 'Info';
    
    // Map backend severity to frontend severity
    if (alert.severity === 'critical' || alert.severity === 'high') severity = 'Critical';
    else if (alert.severity === 'medium' || alert.severity === 'low') severity = 'Warning';
    else severity = 'Info';

    processedAlerts.push({
      id: alert._id || `oci-${alert.timestamp}`,
      source: 'Infrastructure Alerts',
      severity,
      title: `${alert.vm} - ${alert.alertType || 'Alert'}`,
      description: alert.message || 'No description available',
      timestamp: alert.timestamp,
      site: alert.vm,
      category: 'infrastructure'
    });
  });

  // Apply filters
  let filteredAlerts = processedAlerts;

  if (filters.severity?.length > 0) {
    filteredAlerts = filteredAlerts.filter(alert => 
      filters.severity.includes(alert.severity)
    );
  }

  if (filters.source?.length > 0) {
    filteredAlerts = filteredAlerts.filter(alert => 
      filters.source.includes(alert.source)
    );
  }

  if (filters.channel?.length > 0) {
    // For now, we'll filter based on alert type or category
    filteredAlerts = filteredAlerts.filter(alert =>
      filters.channel.some(channel => 
        alert.category.includes(channel.toLowerCase()) ||
        alert.source.toLowerCase().includes(channel.toLowerCase())
      )
    );
  }

  // Apply dynamic filter
  if (filters.dynamicFilter && filters.dynamicFilter !== 'ALL') {
    const filterValue = filters.dynamicFilter.toLowerCase();
    filteredAlerts = filteredAlerts.filter(alert => {
      // For graylog alerts, check channel
      const graylogAlert = graylogAlerts.find(g => g.timestamp === alert.timestamp);
      if (graylogAlert && graylogAlert.channel?.toLowerCase().includes(filterValue.replace('#', ''))) {
        return true;
      }
      
      // For OCI alerts, check vm, tenant, or region
      const ociAlert = ociAlerts.find(o => o.timestamp === alert.timestamp);
      if (ociAlert && (
        ociAlert.vm?.toLowerCase().includes(filterValue) ||
        ociAlert.tenant?.toLowerCase().includes(filterValue) ||
        ociAlert.region?.toLowerCase().includes(filterValue)
      )) {
        return true;
      }
      
      // Check general alert fields
      return alert.title.toLowerCase().includes(filterValue) ||
             alert.description.toLowerCase().includes(filterValue) ||
             alert.site?.toLowerCase().includes(filterValue);
    });
  }

  if (filters.searchText) {
    const searchLower = filters.searchText.toLowerCase();
    filteredAlerts = filteredAlerts.filter(alert =>
      alert.title.toLowerCase().includes(searchLower) ||
      alert.description.toLowerCase().includes(searchLower) ||
      alert.site?.toLowerCase().includes(searchLower)
    );
  }

  // Sort by timestamp (newest first)
  return filteredAlerts.sort((a, b) => 
    new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
  );
};