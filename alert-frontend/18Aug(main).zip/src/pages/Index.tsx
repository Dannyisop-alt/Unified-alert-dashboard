import { useState, useEffect } from 'react';
import { MonitoringDashboard } from '@/components/MonitoringDashboard';
import { HeartbeatMetrics } from '@/components/HeartbeatMetrics';
import { ViewToggle } from '@/components/ViewToggle';
import { DashboardHeader } from '@/components/DashboardHeader';
import { CategoryToggle } from '@/components/CategoryToggle';
import type { AlertCategory, UserPreferences, AlertFilters } from '@/types/alerts';

export type ViewMode = 'alerts' | 'metrics';

const Index = () => {
  const [selectedCategory, setSelectedCategory] = useState<AlertCategory>('logs');
  const [viewMode, setViewMode] = useState<ViewMode>('alerts');
  const [userPreferences, setUserPreferences] = useState<UserPreferences>({
    defaultCategory: 'logs',
    enabledSources: ['Application Heartbeat', 'Application Logs', 'Infrastructure Alerts']
  });
  const [filters, setFilters] = useState<AlertFilters>({
    severity: [],
    source: ['Application Logs'], // Start with logs selected
    channel: [],
    timeRange: '24h',
    searchText: '',
    dynamicFilter: 'ALL'
  });

  // Load user preferences on mount
  useEffect(() => {
    const savedPreferences = localStorage.getItem('userPreferences');
    if (savedPreferences) {
      const preferences = JSON.parse(savedPreferences);
      setUserPreferences(preferences);
      setSelectedCategory(preferences.defaultCategory);
      // Set initial source filter based on category
      const sourceMap = {
        'heartbeat': 'Application Heartbeat',
        'logs': 'Application Logs', 
        'infrastructure': 'Infrastructure Alerts'
      };
      setFilters(prev => ({ ...prev, source: [sourceMap[preferences.defaultCategory]] }));
    }
  }, []);

  // Save preferences and update source filter when category changes
  const handleCategoryChange = (category: AlertCategory) => {
    setSelectedCategory(category);
    const newPreferences = { ...userPreferences, defaultCategory: category };
    setUserPreferences(newPreferences);
    localStorage.setItem('userPreferences', JSON.stringify(newPreferences));
    
    // Auto-select corresponding source
    const sourceMap = {
      'heartbeat': 'Application Heartbeat',
      'logs': 'Application Logs',
      'infrastructure': 'Infrastructure Alerts'
    };
    setFilters(prev => ({ ...prev, source: [sourceMap[category]] }));
  };

  // Calculate critical alert counts only
  const alertCounts = {
    heartbeat: 3, // Mock critical alerts for heartbeat
    logs: 8,      // Mock critical alerts for logs  
    infrastructure: 2  // Mock critical alerts for infrastructure
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="relative">
        {/* Header */}
        <DashboardHeader />
        
        {/* Category Toggle */}
        <CategoryToggle 
          selectedCategory={selectedCategory}
          onCategoryChange={handleCategoryChange}
          alertCounts={alertCounts}
        />
        
        {/* View Toggle */}
        <div className="border-b border-border bg-card/50 backdrop-blur">
          <div className="container mx-auto px-6 py-4">
            <ViewToggle 
              viewMode={viewMode} 
              onViewModeChange={setViewMode} 
              alertCount={alertCounts[selectedCategory]} 
              selectedCategory={selectedCategory}
            />
          </div>
        </div>

        {/* Main Content */}
        <main className="container mx-auto px-6 py-6">
          {viewMode === 'alerts' ? (
            <MonitoringDashboard selectedCategory={selectedCategory} filters={filters} onFiltersChange={setFilters} />
          ) : (
            <HeartbeatMetrics selectedCategory={selectedCategory} />
          )}
        </main>
      </div>
    </div>
  );
};

export default Index;