import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Filter } from 'lucide-react';
import type { AlertFilters, AlertCategory } from '@/types/alerts';

interface FilterPanelProps {
  filters: AlertFilters;
  onFiltersChange: (filters: AlertFilters) => void;
  selectedCategory: AlertCategory;
}

export const FilterPanel = ({ filters, onFiltersChange, selectedCategory }: FilterPanelProps) => {
  const severityOptions = ['Critical', 'Warning', 'Info'];
  const sourceOptions = ['Application Heartbeat', 'Application Logs', 'Infrastructure Alerts'];

  // Dynamic filter options based on selected category
  const getDynamicFilterOptions = () => {
    switch (selectedCategory) {
      case 'logs':
        return ['ALL', '#transit-systems-surveillance', '#alerts', '#monitoring', '#security', '#infrastructure', '#maintenance', '#info'];
      case 'heartbeat':
        return ['ALL', 'Web Services', 'Database Services', 'API Services', 'Background Jobs', 'Message Queue'];
      case 'infrastructure':
        return ['ALL', 'RTD-PROD-01', 'RTD-PROD-02', 'RTD-DEV-01', 'RTD-STAGE-01', 'Production', 'Development', 'Staging'];
      default:
        return ['ALL'];
    }
  };

  const dynamicFilterOptions = getDynamicFilterOptions();
  const toggleSeverity = (severity: string) => {
    const currentSeverities = filters.severity || [];
    const newSeverities = currentSeverities.includes(severity)
      ? currentSeverities.filter(s => s !== severity)
      : [...currentSeverities, severity];
    
    onFiltersChange({ ...filters, severity: newSeverities });
  };

  const toggleSource = (source: string) => {
    const currentSources = filters.source || [];
    const newSources = currentSources.includes(source)
      ? currentSources.filter(s => s !== source)
      : [...currentSources, source];
    
    onFiltersChange({ ...filters, source: newSources });
  };

  const handleDynamicFilterChange = (value: string) => {
    onFiltersChange({ ...filters, dynamicFilter: value });
  };

  return (
    <div className="bg-card border border-border rounded-lg p-4 mb-6">
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2 text-sm font-medium">
          <Filter className="h-4 w-4" />
          Filters
        </div>

        <div className="flex items-center gap-2">
          <Select value={filters.dynamicFilter || 'ALL'} onValueChange={handleDynamicFilterChange}>
            <SelectTrigger className="w-[60px] h-8">
              <SelectValue placeholder="All" />
            </SelectTrigger>
            <SelectContent>
              {dynamicFilterOptions.map((option) => (
                <SelectItem key={option} value={option}>
                  {option}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        
        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground">Severity:</span>
          {severityOptions.map((severity) => (
            <Button
              key={severity}
              variant={filters.severity?.includes(severity) ? 'default' : 'outline'}
              size="sm"
              onClick={() => toggleSeverity(severity)}
              className="h-8"
            >
              {severity}
            </Button>
          ))}
        </div>

        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground">Source:</span>
          {sourceOptions.map((source) => (
            <Button
              key={source}
              variant={filters.source?.includes(source) ? 'default' : 'outline'}
              size="sm"
              onClick={() => toggleSource(source)}
              className="h-8"
            >
              {source}
            </Button>
          ))}
        </div>
      </div>
    </div>
  );
};