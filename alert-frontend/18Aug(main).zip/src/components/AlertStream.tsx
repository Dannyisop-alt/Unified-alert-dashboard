import { useMemo } from 'react';
import { AlertCard } from '@/components/AlertCard';
import { processAlerts } from '@/lib/alertUtils';
import type { GraylogAlert, OCIAlert, AlertFilters } from '@/types/alerts';

interface AlertStreamProps {
  graylogAlerts: GraylogAlert[];
  ociAlerts: OCIAlert[];
  filters: AlertFilters;
}

export const AlertStream = ({ graylogAlerts, ociAlerts, filters }: AlertStreamProps) => {
  const processedAlerts = useMemo(() => {
    return processAlerts(graylogAlerts, ociAlerts, filters);
  }, [graylogAlerts, ociAlerts, filters]);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold text-foreground">
          Live Alert Stream
        </h2>
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <div className="w-2 h-2 bg-success rounded-full animate-pulse-glow"></div>
          {processedAlerts.length} alerts
        </div>
      </div>

      <div className="space-y-3">
        {processedAlerts.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-muted flex items-center justify-center">
              <span className="text-2xl">📊</span>
            </div>
            <p>No alerts match your current filters</p>
          </div>
        ) : (
          processedAlerts.map((alert) => (
            <AlertCard key={alert.id} alert={alert} />
          ))
        )}
      </div>
    </div>
  );
};