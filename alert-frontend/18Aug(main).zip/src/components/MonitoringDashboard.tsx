import { useState, useEffect } from 'react';
import { AlertStream } from '@/components/AlertStream';
import { FilterPanel } from '@/components/FilterPanel';
import { api } from '@/lib/api';
import { processAlerts } from '@/lib/alertUtils';
import type { GraylogAlert, OCIAlert, AlertFilters, AlertCategory } from '@/types/alerts';

interface MonitoringDashboardProps {
  selectedCategory: AlertCategory;
  filters: AlertFilters;
  onFiltersChange: (filters: AlertFilters) => void;
}

export const MonitoringDashboard = ({ selectedCategory, filters, onFiltersChange }: MonitoringDashboardProps) => {
  const [graylogAlerts, setGraylogAlerts] = useState<GraylogAlert[]>([]);
  const [ociAlerts, setOCIAlerts] = useState<OCIAlert[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);


  const fetchAlerts = async () => {
    try {
      setLoading(true);
      setError(null);
      
      const [graylogData, ociData] = await Promise.all([
        api.getGraylogAlerts({ limit: 100 }),
        api.getOCIAlerts({ limit: 100 })
      ]);
      
      setGraylogAlerts(graylogData);
      setOCIAlerts(ociData);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch alerts');
      console.error('Error fetching alerts:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAlerts();

    // Poll for new alerts every 30 seconds
    const interval = setInterval(fetchAlerts, 30000);

    return () => clearInterval(interval);
  }, []);

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="text-center py-12 text-muted-foreground">
          Loading alerts...
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="space-y-6">
        <div className="text-center py-12 text-destructive">
          Error: {error}
          <button 
            onClick={fetchAlerts}
            className="block mx-auto mt-4 px-4 py-2 bg-primary text-primary-foreground rounded hover:bg-primary/90"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <FilterPanel 
        filters={filters} 
        onFiltersChange={onFiltersChange} 
        selectedCategory={selectedCategory}
      />

      <AlertStream 
        graylogAlerts={graylogAlerts}
        ociAlerts={ociAlerts}
        filters={filters}
      />
    </div>
  );
};